# Neon Racer

A small, browser-based arcade racing game that works on desktop and mobile.

## Play locally
1. Download and unzip the project.
2. Open `index.html` in a modern browser.

## Controls
- **Desktop:** Left/Right arrow keys or A/D
- **Mobile:** Tap and hold the on-screen arrow buttons

## Publish with GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html` and `README.md` (or upload the whole unzipped folder).
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. Wait for GitHub Pages to publish your game. The site link will appear in the Pages section.

No libraries, installs, or external assets are required.
